const express = require("express");
const app = express();
//NEW!!!!
const bcrypt = require("bcrypt");
//const users = [{ Name: "Name" }];
const users = [];
app.get("/users", (req, res) => {
  res.json(users); //.status(201);
  //bcrypt.hash(password);
  //bcrypt.hash(password, 10);
  //const ASYNCsalt = bcrypt.genSalt(10);
  //const SYNSalt = bcrypt.genSaltSync(10);
  //bcrypt.hash(password + ASYNCsalt);
  //bcrypt.hash(password, ASYNCsalt);
});

//middleware IMPT!!!!!!
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.post("/usersTEST", (req, res) => {
  const user = { Name: req.body.name, Password: req.body.password };
  users.push(user);
  res.status(201).send();
  //req.body.name = users.keys();
  //req.body.password = users.values();
  //   const users = new Map([
  //   ["alice", "1234"],
  //   ["bob", "abcd"]
  // ]);

  // console.log(users.keys());   // Map Iterator { 'alice', 'bob' }
  // console.log(users.values()); // Map Iterator { '1234', 'abcd' }
  //   req.body.name = [...users.keys()];
  // req.body.password = [...users.values()];
});

app.post("/users", async (req, res) => {
  try {
    const salt = await bcrypt.genSalt();
    const hasedPassword = await bcrypt.hash(req.body.password, salt);
  } catch {}
});
app.listen(3001);
