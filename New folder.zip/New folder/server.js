const express = require("express");
const app = express();
const bcrypt = require("bcrypt");
// const { use } = require("react");

app.use(express.json());

const users = [{ name: "Name" }];

//bcrypt.hash(users, 10); --wrong nice try

app.post("/users", (req, res) => {
  const user = { name: req.params.name, password: req.params.password };
  users.push(user);
  res.status(201).send();
});

app.get("/users", (req, res) => {
  res.json(users); //.status(201); //.status(200);
});

app.listen(3001);
