const fs = require("fs");

//reading files
fs.readFile("./docs/blog1.txt", (err, data) => {
  if (err) {
    console.log(err);
  }
  // else {
  // console.log(data); }
  //console.log(data); - buffer
  //console.log(JSON.stringify(data));
  console.log(data.toString());
});

console.log("last lines");

// fs.readFile("./docs/blog12.txt", (err, data) => {
//   if (err) {
//     console.log(err);
//   }
//   // else {
//   // console.log(data); }
//   //console.log(data); - buffer
//   //console.log(JSON.stringify(data));
//   console.log(data.toString());
// });

// console.log("last lines");
//writing files
fs.writeFile("./docs/blog1.txt", "hello world", () => {
  console.log("file has written");
});

fs.writeFile("./docs/blog2.txt", "hello again", () => {
  console.log("file has written");
});
//directories
if (!fs.existsSync("./assets")) {
  fs.mkdir("./assets", (err) => {
    if (err) {
      console.log(err);
    }
    console.log("folder created");
  });
} else {
  fs.rmdir("./assets", (err) => {
    if (err) {
      console.log(err);
    } else {
      console.log("folder deleted");
    }
  }); // <-- closing the fs.rmdir callback properly
}
//deleting files
if (fs.existsSync("./docs/deleteme.txt")) {
  fs.unlink("./docs/deleteme.txt", (err) => {
    if (err) {
      console.log(err);
    }
    console.log("file deleted");
  });
}
