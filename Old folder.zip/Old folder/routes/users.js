const express = require("express");
const router = express.Router();

// app.get("/users", (req, res) => {
//   res.send("User List");
// });

// app.get("/users/new", (req, res) => {
//   res.send("User New Form");
// });

router.get("/", (req, res) => {
  res.send("User List");
});

router.get("/new", (req, res) => {
  res.send("User New Form");
});

module.exports = router;
