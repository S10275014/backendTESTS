const express = require("express");
const app = express();

const users = [];

app.get("/users", (req, res) => {
  res.json(users);
});
// process.on("SIGINT", (e) => {
//   console.log(e);
// });

app.listen(3001);
